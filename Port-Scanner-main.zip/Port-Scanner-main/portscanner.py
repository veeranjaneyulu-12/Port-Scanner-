import pyfiglet
import sys
import socket
from datetime import datetime

ascii_banner = ascii_banner = r"""
                      ______
                   .-'      '-.
                  /            \
                 |              |
                 |,  .-.  .-.  ,|
                 | )(_o/  \o_)( |
                 |/     /\     \|
                 (_     ^^     _)
                  \__|IIIIII|__/
                   | \IIIIII/ |
                   \          /
                    `--------`
                 ☠ PORT SCANNER ☠
"""

print(ascii_banner)


target = input(str("Target IP: "))

common_ports = {
    21: "FTP",
    22: "SSH",
    23: "Telnet",
    25: "SMTP",
    53: "DNS",
    80: "HTTP",
    110: "POP3",
    143: "IMAP",
    443: "HTTPS",
    445: "SMB",
    3306: "MySQL",

}

print("\nStarting scan on", target)
print("Time started:", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
print("-" * 50)

try:
    for port, service in common_ports.items():
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        socket.setdefaulttimeout(0.5)
        result = s.connect_ex((target, port))
        if result == 0:
            print(f"[+] Port {port} ({service}) is OPEN")
            try:
                banner = s.recv(1024).decode().strip()
                if banner:
                    print(f"    ↳ Banner: {banner}")
            except:
                pass

            s.close()


except KeyboardInterrupt:
    print("\n[!] Scan cancelled by user.")
    sys.exit()

except socket.gaierror:
    print("\n[!] Hostname could not be resolved.")
    sys.exit()

except socket.error:
    print("\n[!] Could not connect to the server.")
    sys.exit()

print("\nScan completed at:", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
